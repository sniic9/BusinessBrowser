# Business Browser

Navigateur Android mobile basé sur Android WebView/Chromium.

Fonctions V1 :
- onglets persistants ;
- restauration après fermeture/réouverture ;
- Google comme page/moteur par défaut ;
- navigation arrière/avant/rechargement ;
- barre d'adresse/recherche ;
- cookies et stockage WebView pour conserver les sessions quand le site les autorise.

## Ouvrir le projet

1. Installer Android Studio.
2. Ouvrir le dossier `BusinessBrowser`.
3. Laisser Gradle synchroniser.
4. Connecter un téléphone Android ou lancer un émulateur.
5. Cliquer sur Run.

## Important

Cette V1 sauvegarde les onglets (nom + URL) et réutilise le stockage WebView/cookies de l'application. Les sites peuvent néanmoins décider de leurs propres règles de session et de restauration.
