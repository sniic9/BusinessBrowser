package com.businessbrowser

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

data class BrowserTab(
    var id: Long,
    var title: String,
    var url: String
)

class MainActivity : androidx.appcompat.app.AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var tabBar: HorizontalScrollView
    private lateinit var tabsContainer: LinearLayout
    private lateinit var address: EditText
    private lateinit var webContainer: FrameLayout

    private val tabs = mutableListOf<BrowserTab>()
    private val webViews = mutableMapOf<Long, WebView>()
    private var activeId: Long = -1L

    private val prefs by lazy { getSharedPreferences("browser", Context.MODE_PRIVATE) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(WebView(this), true)

        buildUi()
        restoreTabs()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFFFFFFF.toInt())
        }

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 8, 8, 4)
        }

        val back = button("‹") { currentWebView()?.goBack() }
        val forward = button("›") { currentWebView()?.goForward() }
        val reload = button("↻") { currentWebView()?.reload() }

        address = EditText(this).apply {
            hint = "Rechercher avec Google ou saisir une URL"
            singleLine = true
            setPadding(18, 0, 18, 0)
            setSelectAllOnFocus(false)
            setOnEditorActionListener { _, _, _ ->
                navigateFromAddress()
                true
            }
        }

        toolbar.addView(back, buttonParams())
        toolbar.addView(forward, buttonParams())
        toolbar.addView(reload, buttonParams())
        toolbar.addView(address, LinearLayout.LayoutParams(0, 48.dp(), 1f))

        val add = button("+") { addTab("Nouvel onglet", "https://www.google.com/") }
        toolbar.addView(add, buttonParams())

        tabBar = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }
        tabsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(6, 2, 6, 2)
        }
        tabBar.addView(tabsContainer)

        webContainer = FrameLayout(this)

        root.addView(toolbar)
        root.addView(tabBar, LinearLayout.LayoutParams(-1, 52.dp()))
        root.addView(webContainer, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun button(text: String, action: () -> Unit): TextView =
        TextView(this).apply {
            this.text = text
            textSize = 22f
            gravity = Gravity.CENTER
            setOnClickListener { action() }
            setPadding(8, 0, 8, 0)
        }

    private fun buttonParams() = LinearLayout.LayoutParams(42.dp(), 48.dp())

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(tab: BrowserTab): WebView {
        return WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.setSupportZoom(false)
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            settings.userAgentString = settings.userAgentString

            webChromeClient = object : WebChromeClient() {
                override fun onReceivedTitle(view: WebView?, title: String?) {
                    title?.takeIf { it.isNotBlank() }?.let {
                        tab.title = it.take(28)
                        saveTabs()
                        renderTabs()
                    }
                }
            }

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest
                ): Boolean = false

                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    if (url != null) {
                        tab.url = url
                        address.setText(url)
                        saveTabs()
                    }
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    if (url != null) {
                        tab.url = url
                        address.setText(url)
                        saveTabs()
                    }
                }
            }

            loadUrl(tab.url)
        }
    }

    private fun addTab(title: String, url: String) {
        val tab = BrowserTab(System.currentTimeMillis(), title, url)
        tabs.add(tab)
        createAndShow(tab)
        saveTabs()
    }

    private fun createAndShow(tab: BrowserTab) {
        val web = createWebView(tab)
        webViews[tab.id] = web
        webContainer.addView(web, FrameLayout.LayoutParams(-1, -1))
        activeId = tab.id
        showActive()
        renderTabs()
    }

    private fun showActive() {
        webViews.forEach { (id, view) ->
            view.visibility = if (id == activeId) View.VISIBLE else View.GONE
        }
        tabs.find { it.id == activeId }?.let { address.setText(it.url) }
    }

    private fun renderTabs() {
        tabsContainer.removeAllViews()
        tabs.forEach { tab ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(14, 0, 4, 0)
                setBackgroundColor(if (tab.id == activeId) 0xFFE8DEF8.toInt() else 0xFFF2F2F2.toInt())
            }

            val title = TextView(this).apply {
                text = tab.title
                textSize = 14f
                maxLines = 1
                setPadding(0, 0, 8, 0)
                setOnClickListener {
                    activeId = tab.id
                    showActive()
                    renderTabs()
                }
            }

            val close = TextView(this).apply {
                text = "×"
                textSize = 18f
                setPadding(8, 0, 8, 0)
                setOnClickListener { closeTab(tab.id) }
            }

            item.addView(title, LinearLayout.LayoutParams(0, 44.dp(), 1f))
            item.addView(close, LinearLayout.LayoutParams(36.dp(), 44.dp()))
            tabsContainer.addView(item, LinearLayout.LayoutParams(190.dp(), 44.dp()).apply {
                setMargins(4, 0, 4, 0)
            })
        }
    }

    private fun closeTab(id: Long) {
        val index = tabs.indexOfFirst { it.id == id }
        if (index < 0) return

        webViews.remove(id)?.let {
            webContainer.removeView(it)
            it.destroy()
        }
        tabs.removeAt(index)

        if (tabs.isEmpty()) {
            addTab("Google", "https://www.google.com/")
            return
        }

        if (activeId == id) {
            activeId = tabs.getOrNull(index)?.id ?: tabs.last().id
        }
        showActive()
        renderTabs()
        saveTabs()
    }

    private fun currentWebView() = webViews[activeId]

    private fun navigateFromAddress() {
        var value = address.text.toString().trim()
        if (value.isEmpty()) return

        if (!value.startsWith("http://") && !value.startsWith("https://")) {
            value = if (value.contains(".") && !value.contains(" ")) {
                "https://$value"
            } else {
                "https://www.google.com/search?q=${java.net.URLEncoder.encode(value, "UTF-8")}"
            }
        }
        currentWebView()?.loadUrl(value)
    }

    private fun restoreTabs() {
        val raw = prefs.getString("tabs", null)
        if (raw.isNullOrBlank()) {
            addTab("Google", "https://www.google.com/")
            return
        }

        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                tabs.add(
                    BrowserTab(
                        o.getLong("id"),
                        o.optString("title", "Onglet"),
                        o.optString("url", "https://www.google.com/")
                    )
                )
            }
            activeId = prefs.getLong("activeId", tabs.first().id)
            tabs.forEach { tab ->
                val web = createWebView(tab)
                webViews[tab.id] = web
                webContainer.addView(web, FrameLayout.LayoutParams(-1, -1))
            }
            if (tabs.none { it.id == activeId }) activeId = tabs.first().id
            showActive()
            renderTabs()
        } catch (_: Exception) {
            tabs.clear()
            addTab("Google", "https://www.google.com/")
        }
    }

    private fun saveTabs() {
        val array = JSONArray()
        tabs.forEach {
            array.put(JSONObject().apply {
                put("id", it.id)
                put("title", it.title)
                put("url", it.url)
            })
        }
        prefs.edit()
            .putString("tabs", array.toString())
            .putLong("activeId", activeId)
            .apply()
    }

    override fun onPause() {
        saveTabs()
        super.onPause()
    }

    override fun onDestroy() {
        saveTabs()
        webViews.values.forEach { it.destroy() }
        webViews.clear()
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (currentWebView()?.canGoBack() == true) {
            currentWebView()?.goBack()
        } else {
            super.onBackPressed()
        }
    }

    private fun Int.dp(): Int =
        (this * resources.displayMetrics.density).toInt()
}
